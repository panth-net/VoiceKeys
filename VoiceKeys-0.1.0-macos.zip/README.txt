========================================
  Voice Keys - Setup Guide (macOS)
========================================

1. INSTALL
   Drag "Voice Keys.app" into your Applications folder.

2. FIRST LAUNCH
   Double-click Voice Keys in Applications.
   macOS will ask you to grant permissions. Allow all three:

   - System Settings > Privacy & Security > Accessibility
   - System Settings > Privacy & Security > Input Monitoring
   - System Settings > Privacy & Security > Microphone

   After granting permissions, quit and reopen Voice Keys.

3. USE IT
   - Click the menu bar icon to open settings and enter your Deepgram API key.
   - Hold your hotkeys, speak, release. Your speech is transcribed and pasted.
   - Recording time is shown next to the menu bar icon.

4. START ON LOGIN (optional)
   System Settings > General > Login Items > click "+" > select Voice Keys.

5. FILES & CONFIG
   Config & API key:  ~/.config/voicekeys/config.yaml
   Log file:          ~/.config/voicekeys/voicekeys.log

   To open in Finder: open ~/.config/voicekeys

6. UNINSTALL
   - Drag Voice Keys from Applications to the Trash.
   - Delete config: rm -rf ~/.config/voicekeys
